package com.example.recyclerdelete

data class ListItem(val id: Int, val text: String, var isChecked: Boolean = false)

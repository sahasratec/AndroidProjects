package com.example.testrecyclerviewdeletelist

data class NameItem(val id: Int, val text: String, var isChecked: Boolean = false)
